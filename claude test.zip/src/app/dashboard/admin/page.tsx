'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import styles from './admin-dashboard.module.css';

type Period = 'day' | 'month' | 'year';

const PERIOD_LABELS: Record<Period, string> = {
  day: "📅 Aujourd'hui",
  month: '📆 Ce mois',
  year: '📊 Cette année',
};

export default function AdminProductionDashboard() {
  const router = useRouter();
  const [period, setPeriod] = useState<Period>('day');
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [palettes, setPalettes] = useState<any[]>([]);
  const [searchCode, setSearchCode] = useState('');
  const [searchResult, setSearchResult] = useState<any | null>(null);
  const [searchError, setSearchError] = useState('');
  const [searching, setSearching] = useState(false);

  const fetchStats = useCallback(async (p: Period) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/stats?period=${p}`);
      const data = await res.json();
      setStats(data.stats);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchStats(period); }, [period, fetchStats]);

  const handleSearch = async () => {
    if (!searchCode.trim()) return;
    setSearching(true);
    setSearchError('');
    setSearchResult(null);
    try {
      const res = await fetch(`/api/chambre/stock?code=${searchCode.trim()}`);
      if (res.ok) {
        const data = await res.json();
        setSearchResult(data.palette || null);
        if (!data.palette) setSearchError('Aucune palette trouvée avec ce code.');
      } else {
        setSearchError('Palette introuvable.');
      }
    } catch (e) {
      setSearchError('Erreur de recherche.');
    } finally {
      setSearching(false);
    }
  };

  const handleExcelExport = () => {
    // Build CSV in-browser
    const headers = ['Période', 'Palettes Entrées', 'Palettes Sorties', 'En Stock', 'Poids Total (kg)', 'Mouvements', 'Utilisateurs Actifs'];
    const row = stats
      ? [period, stats.palettesIn, stats.palettesOut, stats.palettesInChambre, stats.totalWeightKg?.toFixed(1), stats.movements, stats.userCount]
      : ['—', '—', '—', '—', '—', '—', '—'];

    const csv = [headers.join(','), row.join(',')].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rapport-production-${period}-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleLogout = () => {
    // Clear auth tokens
    localStorage.removeItem('bkfood-token');
    localStorage.removeItem('bkfood-user');
    // Redirect to login
    router.push('/login');
  };

  return (
    <div className={styles.container}>
      {/* Mobile Header with Logout */}
      <div className={`${styles.mobileHeader} mobile-only`}>
        <h2 className={styles.title}>📊 Admin Production</h2>
        <button className={styles.mobileLogoutBtn} onClick={handleLogout}>
          🚪 Déconnexion
        </button>
      </div>

      {/* Desktop Header */}
      <div className={`${styles.header} desktop-only`}>
        <div>
          <h2 className={styles.title}>📊 Admin Production</h2>
          <p className={styles.subtitle}>Consultation totale · Rapports · Statistiques · Traçabilité</p>
        </div>
        <div className={styles.headerActions}>
          <button className={styles.exportBtn} onClick={handleExcelExport}>
            📥 Exporter Excel
          </button>
          <button className={styles.logoutBtn} onClick={handleLogout}>
            🚪 Déconnexion
          </button>
        </div>
      </div>

      {/* Period Tabs */}
      <div className={styles.periodTabs}>
        {(Object.keys(PERIOD_LABELS) as Period[]).map(p => (
          <button
            key={p}
            className={`${styles.periodTab} ${period === p ? styles.periodTabActive : ''}`}
            onClick={() => setPeriod(p)}
          >
            {PERIOD_LABELS[p]}
          </button>
        ))}
      </div>

      {/* Stats Grid */}
      {loading ? (
        <div className={styles.loadingRow}>⏳ Chargement des statistiques...</div>
      ) : stats ? (
        <div className={styles.statsGrid}>
          <StatCard icon="📥" label="Palettes Entrées" value={stats.palettesIn} color="#3b82f6" />
          <StatCard icon="📤" label="Palettes Sorties" value={stats.palettesOut} color="#8b5cf6" />
          <StatCard icon="❄️" label="En Chambre (stock)" value={stats.palettesInChambre} color="#06b6d4" />
          <StatCard icon="⚖️" label="Poids Total (kg)" value={`${stats.totalWeightKg?.toFixed(1)} kg`} color="#f59e0b" />
          <StatCard icon="🔄" label="Mouvements" value={stats.movements} color="#10b981" />
          <StatCard icon="👥" label="Utilisateurs Actifs" value={stats.userCount} color="#f43f5e" />
        </div>
      ) : (
        <div className={styles.loadingRow}>❌ Erreur de chargement des statistiques</div>
      )}

      {/* Product Journey Search */}
      <div className={styles.section}>
        <h3 className={styles.sectionTitle}>🔍 Recherche Trajet Produit</h3>
        <div className={styles.searchRow}>
          <input
            className={styles.searchInput}
            placeholder="Code palette (ex: PAL-001)..."
            value={searchCode}
            onChange={e => setSearchCode(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
          />
          <button className={styles.searchBtn} onClick={handleSearch} disabled={searching}>
            {searching ? '⏳' : '🔍 Rechercher'}
          </button>
        </div>

        {searchError && <p className={styles.searchError}>❌ {searchError}</p>}

        {searchResult && (
          <div className={styles.resultCard}>
            <h4>📦 Palette : {searchResult.code}</h4>
            <div className={styles.resultGrid}>
              <InfoRow label="Statut" value={searchResult.status} />
              <InfoRow label="Espèce" value={searchResult.species} />
              <InfoRow label="Article" value={searchResult.article} />
              <InfoRow label="Poids" value={`${searchResult.weightKg} kg`} />
              <InfoRow label="Origine" value={searchResult.origin} />
              <InfoRow label="Entrée Chambre" value={searchResult.entryTime ? new Date(searchResult.entryTime).toLocaleString('fr-FR') : '—'} />
              <InfoRow label="Sortie Chambre" value={searchResult.exitTime ? new Date(searchResult.exitTime).toLocaleString('fr-FR') : '—'} />
              <InfoRow label="Opérateur" value={searchResult.chambreWorkerId || '—'} />
              <InfoRow label="Position" value={searchResult.positionZone ? `${searchResult.positionZone}${searchResult.positionNumber}` : '—'} />
            </div>

            {searchResult.movements && searchResult.movements.length > 0 && (
              <div className={styles.timeline}>
                <h5>🗺️ Trajet</h5>
                {searchResult.movements.map((m: any, i: number) => (
                  <div key={i} className={styles.timelineItem}>
                    <div className={styles.timelineDot} />
                    <div>
                      <strong>{m.fromStation} → {m.toStation}</strong>
                      <span className={styles.timelineOp}> · {m.workerMatricule}</span>
                      <div className={styles.timelineDate}>{new Date(m.timestamp).toLocaleString('fr-FR')}</div>
                      {m.notes && <div className={styles.timelineNotes}>{m.notes}</div>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Access Info Card */}
      <div className={styles.accessCard}>
        <h4>🛡️ Vos Accès — Admin Production</h4>
        <ul className={styles.accessList}>
          <li>✅ Consultation de <strong>toutes les données</strong> de production</li>
          <li>✅ Rapports <strong>Jour / Mois / Année</strong></li>
          <li>✅ Statistiques en temps réel (palettes, poids, mouvements)</li>
          <li>✅ Recherche du <strong>trajet complet</strong> d'un produit</li>
          <li>✅ <strong>Export Excel/CSV</strong> de tous les rapports</li>
          <li>❌ Gestion des utilisateurs (réservé Super Admin IT)</li>
        </ul>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color }: { icon: string; label: string; value: any; color: string }) {
  return (
    <div className={styles.statCard}>
      <div className={styles.statIcon} style={{ background: color + '18', color }}>{icon}</div>
      <div className={styles.statValue} style={{ color }}>{value}</div>
      <div className={styles.statLabel}>{label}</div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className={styles.infoRow}>
      <span className={styles.infoLabel}>{label}</span>
      <span className={styles.infoValue}>{value}</span>
    </div>
  );
}
