import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { verifyToken } from '@/lib/jwt';

export async function POST(request: NextRequest) {
    try {
        const { numero, article, boxCount, ligneId } = await request.json();

        const authHeader = request.headers.get('Authorization');
        let cheffeMatricule = 'SYSTEM';
        if (authHeader?.startsWith('Bearer ')) {
            const payload = await verifyToken(authHeader.substring(7));
            cheffeMatricule = (payload.matricule as string) || 'SYSTEM';
        }

        // Generate unique barcode for chariot: CHR-YYYYMMDD-XXXX
        const date = new Date().toISOString().split('T')[0].replace(/-/g, '');
        const count = await prisma.chariot.count({
            where: {
                createdAt: {
                    gte: new Date(new Date().setHours(0, 0, 0, 0)),
                },
            },
        });
        const code = `CHR-${date}-${(count + 1).toString().padStart(4, '0')}`;

        const chariot = await prisma.chariot.create({
            data: {
                code,
                numero,
                article,
                boxCount: parseInt(boxCount),
                ligneId,
                cheffeMatricule,
                status: 'READY_FOR_AUTOCLAVE',
            },
        });

        // 🤖 ML Hook: Box Count Anomaly Detection
        const mlResponse = await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/ml/check-boxes`, {
            method: 'POST',
            body: JSON.stringify({ chariotCode: code, boxCount: parseInt(boxCount), article })
        }).catch(() => null);

        return NextResponse.json({ success: true, chariot, mlAlert: mlResponse?.status === 300 });
    } catch (error) {
        console.error('[chariot-create]', error);
        return NextResponse.json({ error: 'Erreur création chariot' }, { status: 500 });
    }
}
