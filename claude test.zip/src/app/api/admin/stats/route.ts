import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url);
        const period = searchParams.get('period') || 'day'; // day | month | year

        const now = new Date();
        let startDate: Date;

        if (period === 'year') {
            startDate = new Date(now.getFullYear(), 0, 1);
        } else if (period === 'month') {
            startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        } else {
            startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        }

        const [
            totalPalettes,
            palettesIn,
            palettesOut,
            palettesInChambre,
            movements,
            userCount,
        ] = await Promise.all([
            prisma.palette.count(),
            prisma.palette.count({ where: { entryTime: { gte: startDate } } }),
            prisma.palette.count({ where: { exitTime: { gte: startDate }, status: 'SENT_TO_LIGNE' } }),
            prisma.palette.count({ where: { status: 'IN_CHAMBRE' } }),
            prisma.paletteMovement.count({ where: { timestamp: { gte: startDate } } }),
            prisma.user.count({ where: { isApproved: true } }),
        ]);

        // Weight totals
        const weightResult = await prisma.palette.aggregate({
            _sum: { weightKg: true },
            where: { entryTime: { gte: startDate } },
        });

        return NextResponse.json({
            period,
            startDate,
            stats: {
                totalPalettes,
                palettesIn,
                palettesOut,
                palettesInChambre,
                movements,
                userCount,
                totalWeightKg: weightResult._sum.weightKg || 0,
            },
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
