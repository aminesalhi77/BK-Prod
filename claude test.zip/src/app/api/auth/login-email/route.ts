import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import prisma from '@/lib/prisma';
import { signToken } from '@/lib/jwt';

export async function POST(request: NextRequest) {
    try {
        const { email, password } = await request.json();

        if (!email || !password) {
            return NextResponse.json({ error: 'Email et mot de passe requis' }, { status: 400 });
        }

        const user = await prisma.user.findUnique({ where: { email } });
        if (!user) {
            return NextResponse.json({ error: 'Identifiants invalides' }, { status: 401 });
        }

        const valid = await bcrypt.compare(password, user.password);
        if (!valid) {
            return NextResponse.json({ error: 'Identifiants invalides' }, { status: 401 });
        }

        if (!user.isApproved) {
            return NextResponse.json({ error: 'Compte en attente d\'approbation', code: 'PENDING' }, { status: 403 });
        }

        const token = await signToken({
            sub: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            module: user.assignedModule,
        });

        return NextResponse.json({
            token,
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role,
                assignedModule: user.assignedModule,
            },
        });
    } catch (error: any) {
        console.error('[login-email]', error);
        return NextResponse.json({ error: error.message || 'Erreur interne du serveur' }, { status: 500 });
    }
}
