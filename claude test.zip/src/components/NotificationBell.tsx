'use client';

import { useState, useEffect, useRef } from 'react';
import { Bell, BellRing, X } from 'lucide-react';
import { useApp } from '@/context/AppContext';

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  recipientRole: string;
  recipientModule?: string;
  relatedEntity?: string;
  relatedId?: string;
  isRead: boolean;
  createdAt: string;
  readAt?: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
}

export default function NotificationBell() {
  const { user, token } = useApp();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const bellRef = useRef<HTMLDivElement>(null);

  const fetchNotifications = async () => {
    if (!user || !token) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/notifications', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();

      if (data.success) {
        setNotifications(data.notifications);
        setUnreadCount(data.unreadCount);
      }
    } catch (error) {
      console.error('Error fetching notifications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const markAsRead = async (notificationId: string) => {
    if (!token) return;

    try {
      await fetch('/api/notifications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ notificationId }),
      });

      setNotifications(prev => 
        prev.map(n => 
          n.id === notificationId ? { ...n, isRead: true, readAt: new Date().toISOString() } : n
        )
      );
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    const unreadNotifications = notifications.filter(n => !n.isRead);
    for (const notification of unreadNotifications) {
      await markAsRead(notification.id);
    }
  };

  useEffect(() => {
    if (user && token) {
      fetchNotifications();
      
      // Poll for new notifications every 30 seconds
      const interval = setInterval(fetchNotifications, 30000);
      return () => clearInterval(interval);
    }
  }, [user, token]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (bellRef.current && !bellRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!user) return null;

  const hasUnread = unreadCount > 0;
  const BellIcon = hasUnread ? BellRing : Bell;

  return (
    <div className="relative">
      {/* Notification Bell */}
      <div ref={bellRef}>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="relative p-2 text-gray-600 hover:text-gray-900 transition-colors"
          aria-label="Notifications"
        >
        <BellIcon className="h-6 w-6" />
          {hasUnread && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold animate-pulse">
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </button>

        {/* Notification Dropdown */}
        {isOpen && (
          <div className="absolute right-0 mt-2 w-96 bg-gradient-to-br from-white to-gray-50 rounded-xl shadow-2xl border border-gray-200/50 z-50 max-h-96 overflow-hidden backdrop-blur-sm animate-in slide-in-from-top-2 duration-200">
            {/* Header */}
            <div className="p-4 border-b border-gray-200/50 bg-gradient-to-r from-blue-50 to-indigo-50">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                  <h3 className="font-semibold text-gray-900 text-lg">Notifications</h3>
                </div>
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    className="text-sm text-blue-600 hover:text-blue-800 font-semibold transition-colors bg-white/50 px-3 py-1 rounded-full hover:bg-white"
                  >
                    Tout marquer comme lu
                  </button>
                )}
              </div>
              {unreadCount > 0 && (
                <div className="mt-2 text-sm text-gray-600">
                  {unreadCount} notification{unreadCount > 1 ? 's' : ''} non lue{unreadCount > 1 ? 's' : ''}
                </div>
              )}
            </div>

            {/* Notifications List */}
            <div className="max-h-80 overflow-y-auto custom-scrollbar">
              {isLoading ? (
                <div className="p-6 text-center text-gray-500">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="mt-2">Chargement...</p>
                </div>
              ) : notifications.length === 0 ? (
                <div className="p-6 text-center text-gray-500">
                  <div className="text-4xl mb-2">📭</div>
                  <p>Aucune notification</p>
                </div>
              ) : (
                notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 border-b border-gray-100/50 hover:bg-white/80 cursor-pointer transition-all duration-200 transform hover:translate-x-1 ${
                      !notification.isRead ? 'bg-gradient-to-r from-blue-50 to-indigo-50 border-l-4 border-l-blue-500 shadow-sm' : 'bg-white'
                    }`}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className="flex items-start justify-between group">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <span className={`px-3 py-1 rounded-full text-xs font-bold tracking-wide ${
                            notification.priority === 'HIGH' || notification.priority === 'URGENT'
                              ? 'bg-red-100 text-red-800 border border-red-200 shadow-sm'
                              : notification.priority === 'MEDIUM'
                              ? 'bg-yellow-100 text-yellow-800 border border-yellow-200 shadow-sm'
                              : 'bg-gray-100 text-gray-800 border border-gray-200 shadow-sm'
                          }`}>
                            {notification.priority}
                          </span>
                          {!notification.isRead && (
                            <span className="w-3 h-3 bg-blue-500 rounded-full animate-pulse shadow-lg"></span>
                          )}
                        </div>
                        <h4 className="font-bold text-gray-900 text-sm mb-1 leading-tight">{notification.title}</h4>
                        <p className="text-sm text-gray-700 leading-relaxed">{notification.message}</p>
                        <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
                          <span className="flex items-center gap-1">
                            <span className="w-2 h-2 bg-gray-400 rounded-full"></span>
                            {new Date(notification.createdAt).toLocaleString('fr-FR')}
                          </span>
                          {notification.relatedEntity && (
                            <span className="flex items-center gap-1 text-blue-600">
                              <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                              {notification.relatedEntity}
                            </span>
                          )}
                        </div>
                      </div>
                      {!notification.isRead && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            markAsRead(notification.id);
                          }}
                          className="ml-3 opacity-0 group-hover:opacity-100 transition-all duration-200 bg-white shadow-md hover:shadow-lg border border-gray-200 rounded-full p-2 hover:bg-gray-50"
                        >
                          <svg className="w-4 h-4 text-gray-600 hover:text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-gray-200/50 bg-gray-50/50 text-center text-xs text-gray-500 font-medium">
              <span className="flex items-center justify-center gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                Dernière mise à jour: {new Date().toLocaleTimeString('fr-FR')}
              </span>
            </div>
          </div>
        )}
      </div>

    </div>
  );
}